package com.futu.openapi;


public class FTAPI {
    public static void init()
    {
        FTCAPI.INSTANCE.FTAPIChannel_Init();
    }

    public static void unInit()
    {
        FTCAPI.INSTANCE.FTAPIChannel_UnInit();
    }
}
