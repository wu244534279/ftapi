package com.futu.openapi;

public class LoadLibError extends APIError {
    public LoadLibError(String msg) {
        super(msg);
    }
}
