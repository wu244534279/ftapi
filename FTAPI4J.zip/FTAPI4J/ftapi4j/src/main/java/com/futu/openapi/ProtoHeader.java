package com.futu.openapi;

import com.sun.jna.Structure;
import com.sun.org.apache.xpath.internal.operations.String;

import java.util.Arrays;

public class ProtoHeader extends Structure {
    public class ByReference extends ProtoHeader implements Structure.ByReference{}

    public byte[] szHeaderFlag = {'F', 'T'};
    public int nProtoID;
    public byte nProtoFmtType;
    public byte nProtoVer;
    public int nSerialNo;
    public int nBodyLen;
    public byte[] arrBodySHA1 = new byte[20];
    public byte[] arrReserved = {0, 0, 0, 0, 0, 0, 0, 0};

    public ProtoHeader() {
        super(ALIGN_NONE);
    }

    protected java.util.List getFieldOrder() {
        return Arrays.asList("szHeaderFlag",
                "nProtoID",
                "nProtoFmtType",
                "nProtoVer",
                "nSerialNo",
                "nBodyLen",
                "arrBodySHA1",
                "arrReserved");
    }
}