package com.futu.openapi;

public enum ReqReplyType {
    SvrReply(0),
    Timeout(-100),
    DisConnect(-200);

    private int code;

    private ReqReplyType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public static ReqReplyType fromCode(int code) {
        for (ReqReplyType item : values()) {
            if (item.code == code) return item;
        }
        return null;
    }
}
