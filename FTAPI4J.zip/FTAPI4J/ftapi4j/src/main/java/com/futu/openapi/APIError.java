package com.futu.openapi;

public class APIError extends RuntimeException {
    public APIError(String msg) {
        super(msg);
    }
}
