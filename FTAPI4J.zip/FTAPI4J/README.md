## FTAPI4J

Futu Open API的Java版本。

### 目录结构：

1. ftapi4j：java接口工程
2. sample：示例
3. lib：依赖的库，其中各平台目录下是依赖的动态库，在运行时需要将对应动态库复制到运行目录中。

### 编译：

默认使用maven编译，ftapi4j和sample目录下有对应的pom，直接用maven构建即可。

ftapi4j打包后，默认会放到lib目录下。lib目录下自带的ftapi4j.jar使用AdoptOpenJDK8u222b10-x64构建。